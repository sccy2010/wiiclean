| Q                | A
| ---------------- | -----
| Bug report?      | [ ]
| Feature request? | [ ]
| Support request? | [ ]

<!--
- For support request or how-tos you can also use Stack Overflow
to ask/answer Cocorico questions.
- Replace this comment by the description of your issue.
-->
