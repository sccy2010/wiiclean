| Q             | A
| ------------- | ---
| Bug fix?      | [ ]
| New feature?  | [ ]
| Tests pass?   | [ ]
| Fixed issues  | #... <!-- number of issue if any -->
| License       | MIT

<!--
- Replace this comment by a description of what your PR is solving.
-->

## Checklist:

- [ ] Update [CHANGELOG.md](https://github.com/Cocolabs-SAS/cocorico/blob/master/CHANGELOG.md)