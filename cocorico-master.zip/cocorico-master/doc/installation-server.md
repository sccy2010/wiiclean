# Server Installation

- For a quick installation based on Docker see [Docker installation](https://github.com/Cocolabs-SAS/cocorico-docker)

- For a manual installation on Linux see [Linux installation](installation-server-linux.md)

- For a manual installation on Windows see [Windows installation](installation-server-windows.md)