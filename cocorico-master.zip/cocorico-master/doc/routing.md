# Routing

## Extra Bundle Routing

To add new Bundles routing to the app add their path to `Cocorico/CoreBundle/Routing/ExtraBundleLoader.php`
