# Troubleshooting

Errors and exceptions are logged and rotated at the application level:

    $ tail -f app/logs/dev-yyyy-mm-dd.log
    $ tail -f app/logs/prod-yyyy-mm-dd.log