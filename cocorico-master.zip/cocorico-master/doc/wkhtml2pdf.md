# Install WkHtml2PDF

    cd mytmpfolder
    wget http://download.gna.org/wkhtmltopdf/0.12/0.12.3/wkhtmltox-0.12.3_linux-generic-amd64.tar.xz
    sudo tar xvf wkhtmltox-0.12.3_linux-generic-amd64.tar.xz
    sudo mkdir /usr/local/bin
    sudo mv wkhtmltox/bin/wkhtmlto* /usr/local/bin/